<?php 

session_start(); 

include "db_conn.php";

if (isset($_POST['uname']) && isset($_POST['password'])) {

    function validate($data){
       $data = trim($data);
       $data = stripslashes($data);
       $data = htmlspecialchars($data);
       return $data;
    }

    $uname = validate($_POST['uname']);
    $pass = validate($_POST['password']);

    if (empty($uname)) {
        header("Location: index.php?error=User Name is required");
        exit();
    } else if(empty($pass)) {
        header("Location: index.php?error=Password is required");
        exit();
    } else {
        $sql = "SELECT * FROM users WHERE user_name=? AND password=?";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("Location: index.php?error=SQL error");
            exit();
        } else {
            mysqli_stmt_bind_param($stmt, "ss", $uname, $pass);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            if (mysqli_num_rows($result) === 1) {
                $row = mysqli_fetch_assoc($result);
                if ($row['user_name'] === $uname && $row['password'] === $pass) {       
                    $_SESSION['user_name'] = $row['user_name'];
                    $_SESSION['name'] = $row['name'];
                    $_SESSION['id'] = $row['id'];

                    if(isset($_SESSION['user_name']) && $_SESSION['user_name'] == 'admin') {
                        header('Location: admin.php');
                    } else {
                        header('Location: homepage.php');
                    }
                } else {
                    header("Location: index.php?error=Incorrect Username or password");
                    exit();
                }
            } else {
                header("Location: index.php?error=Incorrect Username or password");
                exit();
            }
        }
    }
} else {
    header("Location: index.php");
    exit();
}
