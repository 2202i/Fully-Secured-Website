

CREATE TABLE `customer` (

  `fname` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `message` varchar(255) NOT NULL,
  
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

