<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv= "X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Kopi | Shop</title>

    
</head>
<body>
    <div class = "container">
        <div class = "nav-bar">
            <h1 class="title" >Cof<span>fee</span></h1> </a>
            <p> Coffee Shop </p>
            <ul class="menu">
            <li><a href="homepageadmin.php">HOME</a></li>
            <li><a href="admin.php">ADMIN</a></li>
            <li><a href="Contactuspageadmin.php">CONTACT US</a></li>
            <li><a href="aboutadmin.php">ABOUT</a></li>
            <li><a href="logout.php">Logout</a></li>
            
            </ul>
        </div>
        
        <p class="about">What our customers say about us:<p>
        <div class="reviews">
        
            <div class="review">
                <h3>Amazing Coffee</h3>
                <p>Great coffee, great atmosphere, great service! I would definitely recommend this place to anyone looking for a good cup of coffee.</p>
                <p class="author">- John Smith</p>
            </div>
            <div class="review">
                <h3>Best coffee in town!</h3>
                <p>I've tried a lot of coffee places in the area, and this is by far the best. The coffee is always fresh and delicious, and the staff is super friendly.</p>
                <p class="author">- Sarah Johnson</p>
            </div>
            <div class="review">
                <h3>Great place to hang out</h3>
                <p>Not only does this place have great coffee, but it's also a great place to hang out and get some work done. The atmosphere is cozy and inviting, and the wifi is fast and reliable.</p>
                <p class="author">- Mike Davis</p>
            </div>
            <div class="review">
                <h3>Cozy atmosphere</h3>
                <p>This place has a really cozy atmosphere that makes you feel right at home. The coffee is great too!</p>
                <p class="author">- Emily Thompson</p>
            </div>
            <div class="review">
                <h3>Excellent service</h3>
                <p>The service here is top-notch. The staff is friendly and attentive, and they always make sure your order is perfect.</p>
                <p class="author">- Michael Lee</p>
            </div>

        </div>
    </div>

    








    <footer>

<div class="footer-grid">
    <ul class="contact-info">
        <li><h4>Contact Information</h4></li>
        <li><strong>Phone:</strong> (+63) 965-390-8872</li>
        <li><strong>Email:</strong> coffeeshopweb@gmail.com</li>
        <li><strong>Address:</strong> 464 Santo Rosario St, Angeles, Pampanga</li>
    </ul>
    <ul class="social-media">
    <li><h4> <a href="https://www.canva.com/design/DAFhwtCI6UA/HNiZMGQEZMoy9Ys2_MzBcA/edit?utm_content=DAFhwtCI6UA&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton" >Meet our Team</h4> </a></li>
        <li><a href="https://www.canva.com/design/DAFhwtCI6UA/HNiZMGQEZMoy9Ys2_MzBcA/edit?utm_content=DAFhwtCI6UA&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
    </ul>
    <ul class="legal"> 
        <li><a href="https://docs.google.com/document/d/1xYnU9C4r-P7f4fRulPx9LGGQ6UCwoIPs/" target="_blank">Privacy Policy and Terms of Service</a></li>
    </ul>
</div>
</footer>
</body>
</html>
