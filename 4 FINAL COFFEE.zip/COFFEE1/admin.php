<!DOCTYPE html>

<?php 

session_start(); 

include "db_conn.php";

if (!isset($_SESSION['user_name']) || $_SESSION['user_name'] !== 'admin') {
    header("Location: homepage.php");
    exit;
}
?>

<head>
    <meta charset="UTF-8">
    <meta http-equiv= "X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Kopi | Shop</title>

</head>


<body>
    <div class = "container">
        <div class = "nav-bar">
            <h1 class="title" >Cof<span>fee</span></h1> </a>
            <p> Coffee Shop </p>
            <ul class="menu">
            <li><a href="homepageadmin.php">HOME</a></li>
            <li><a href="admin.php">ADMIN</a></li>
            <li><a href="Contactuspageadmin.php">CONTACT US</a></li>
            <li><a href="aboutadmin.php">ABOUT</a></li>
            <li><a href="logout.php">Logout</a></li>
            
            </ul>
        </div>
      
    </div>
    <div class = "container">  
    <div id="menu">
    <?php
// (A) PROCESS ORDER FORM
if (isset($_POST["name"])) {
  require "process.php"; 
  echo $result == "" 
    ? "<div class='notify'>Thank You! We have received your order</div>" 
    : "<div class='notify'>$result</div>" ;
}
?>  
    <h1 id = "section"><span> MENU</span> </h1>
        <div id="menu_row">
            <div id = "menu_col">
<!--------------------- COFFEE ------------------------->
            <h2>COFFEE</h2>
                <div class = "box">
                <div id = "image">
                <img src="coffeemenu/americano.jpg">
                </div>
            <div>
                <h3><span>AMERICANO</span></h3>
                <h4>90.00</h4>
            </div>
        </div>

        <div class = "box">
                <div id = "image">
                    <img src="coffeemenu/capuccino.jpg">
                </div>
            <div>
                <h3><span>CAPPUCINO</span></h3>
                <h4>110.00</h4>
            </div>
        </div>

        <div class = "box">
                <div id = "image">
                <img src="coffeemenu/caffelatte.jpg">
                </div>
            <div>
                <h3><span>CAFFE LATTE</span></h3>
                <h4>120.00</h4>
            </div>
            </div>
            <div class = "box">
            <div id = "image">
                <img src="coffeemenu/macchiato.jpg">
            </div>
            <div>
                <h3><span>MACCHIATO</span></h3>
                <h4>120.00</h4>
            </div>
            </div>
            <div class = "box">
            <div id = "image">
                <img src="coffeemenu/espresso.jpg">
            </div>
            <div>
                <h3><span>ESPRESSO</span></h3>
                <h4>80.00</h4>
            </div>
            </div>
            <div class = "box">
            <div id = "image">
                <img src="coffeemenu/caramellatte.jpg">
            </div>
            <div>
                <h3><span>CARAMEL LATTE</span></h3>
                <h4>130.00</h4>
            </div>
            </div>
            <div class = "box">
            <div id = "image">
                <img src="coffeemenu/affogato.jpg">
            </div>
            <div>
                <h3><span>AFFOGATO</span></h3>
                <h4>130.00</h4>
            </div>
            </div>
    
            </div>

<!------------------NON - COFFEE ----------------------->
            <div id = "menu_col">
            <h2>NON-COFFEE</h2>
                <div class = "box">
                <div id = "image">
                <img src="coffeemenu/chamomile.jpg">
                </div>
            <div>
                <h3><span>CHAMOMILE</span></h3>
                <h4>100.00</h4>
            </div>
        </div>

        <div class = "box">
                <div id = "image">
                    <img src="coffeemenu/blacktea.jpg">
                </div>
            <div>
                <h3><span>BLACK TEA</span></h3>
                <h4>90.00</h4>
            </div>
        </div>

        <div class = "box">
                <div id = "image">
                <img src="coffeemenu/earlgrey.jpg">
                </div>
            <div>
                <h3><span>EARL GREY</span></h3>
                <h4>100.00</h4>
            </div>
            </div>
            <div class = "box">
                <div id = "image">
                <img src="coffeemenu/lycheetea.jpg">
                </div>
            <div>
                <h3><span>LYCHEE TEA</span></h3>
                <h4>120.00</h4>
            </div>
            </div>
            <div class = "box">
                <div id = "image">
                <img src="coffeemenu/milktea.jpg">
                </div>
            <div>
                <h3><span>MILK TEA</span></h3>
                <h4>120.00</h4>
            </div>
            </div>
 
            </div>
<!---------------- PASTRY ---------------------->
            <div id = "menu_col">
            <h2>PASTRY</h2>
                <div class = "box">
                <div id = "image">
                <img src="coffeemenu/cinnamonroll.jpg">
                </div>
            <div>
                <h3><span>CINNAMON ROLL</span></h3>
                <h4>25.00</h4>
            </div>
        </div>

        <div class = "box">
                <div id = "image">
                    <img src="coffeemenu/almondroll.jpg">
                </div>
            <div>
                <h3><span>ALMOND ROLL</span></h3>
                <h4>25.00</h4>
            </div>
        </div>

        <div class = "box">
                <div id = "image">
                <img src="coffeemenu/bananabread.jpg">
                </div>
            <div>
                <h3><span>BANANA BREAD</span></h3>
                <h4>30.00</h4>
            </div>
            </div>


            <div class = "box">
                <div id = "image">
                <img src="coffeemenu/chocomuffin.jpg">
                </div>
            <div>
                <h3><span>CHOCO MUFFIN</span></h3>
                <h4>30.00</h4>
            </div>
            </div>
            
            <div class = "box">
                <div id = "image">
                <img src="coffeemenu/glazeddonut.jpg">
                </div>
            <div>
                <h3><span>GLAZED DONUT</span></h3>
                <h4>30.00</h4>
            </div>
            </div>
            
            <div class = "box">
                <div id = "image">
                <img src="coffeemenu/grilledcheese.jpg">
                </div>
            <div>
                <h3><span>GRILLED CHEESE</span></h3>
                <h4>30.00</h4>
            </div>
            </div>
            
            <div class = "box">
                <div id = "image">
                <img src="coffeemenu/chickenbread.jpg">
                </div>
            <div>
                <h3><span>CHICKEN BREAD</span></h3>
                <h4>30.00</h4>
            </div>
            </div>
            
            <div class = "box">
                <div id = "image">
                <img src="coffeemenu/tunapuff.jpg">
                </div>
            <div>
                <h3><span>TUNA PUFF</span></h3>
                <h4>30.00</h4>
            </div>
            </div>

            </div>

        </div>
       
    </div>




<form method="post" target="_self" >
<h2 class="title-2">What would you like to order? </h2>
  <label>Name</label>
  <input type="text" name="name" placeholder="Enter your name" required value = "" >
 
  <label>Email</label>
  <input type="email" name="email" placeholder="Enter your email address" required value = ""  >

  <label>What is your order?</label>
  <input type="text" name="coffee" placeholder="ex. Black Coffee" required value = "" >

  <label>Quantity</label>
  <input type="number" name="qty" placeholder="ex. 1" required value = ""  >

  <label>What kind of design?</label>
  <input type="file" id="file" name="file">
 
  <input type="submit" value="Place Order">
</form> 
</div>
      

<!--------------------------FOOTER-------------------------------------------------------->


<footer>

<div class="footer-grid">
    <ul class="contact-info">
        <li><h4>Contact Information</h4></li>
        <li><strong>Phone:</strong> (+63) 965-390-8872</li>
        <li><strong>Email:</strong> coffeeshopweb@gmail.com</li>
        <li><strong>Address:</strong> 464 Santo Rosario St, Angeles, Pampanga</li>
    </ul>
    <ul class="social-media">
    <li><h4> <a href="https://www.canva.com/design/DAFhwtCI6UA/HNiZMGQEZMoy9Ys2_MzBcA/edit?utm_content=DAFhwtCI6UA&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton" >Meet our Team</h4> </a></li>
        <li><a href="https://www.canva.com/design/DAFhwtCI6UA/HNiZMGQEZMoy9Ys2_MzBcA/edit?utm_content=DAFhwtCI6UA&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
    </ul>
    <ul class="legal"> 
        <li><a href="https://docs.google.com/document/d/1xYnU9C4r-P7f4fRulPx9LGGQ6UCwoIPs/" target="_blank">Privacy Policy and Terms of Service</a></li>
    </ul>
</div>
</footer>
</body>


</html>

