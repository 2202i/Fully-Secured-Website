<?php
// (A) PROCESS RESULT
$result = "";

// (B) CONNECT TO DATABASE - CHANGE SETTINGS TO YOUR OWN!
$dbhost = "localhost";
$dbname = "test";
$dbchar = "utf8mb4";
$dbuser = "root";
$dbpass = "";
$pdo = new PDO(
  "mysql:host=$dbhost;dbname=$dbname;charset=$dbchar",
  $dbuser, $dbpass, [
  PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
  PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
]);

// (C) SAVE ORDER TO DATABASE
if ($result=="") { try {
  $stmt = $pdo->prepare("INSERT INTO `customer` (`fname`,`surname`,`email`,`phone`,`message`) VALUES (?,?,?,?,?)");
  $stmt->execute([$_POST["fname"],$_POST["surname"], $_POST["email"], $_POST["phone"], $_POST["message"]]);
} catch (Exception $ex) { $result = $ex->getMessage(); }}

