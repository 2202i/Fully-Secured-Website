<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv= "X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Kopi | Shop</title>

</head>

	  

<body>


<div class = "container">
        <div class = "nav-bar">
            <h1 class="title" >Cof<span>fee</span></h1> </a>
            <p> Coffee Shop </p>
            <ul class="menu">
              <li><a href="homepage.php">HOME</a></li>
              <li><a href="Products.php">PRODUCTS</a></li>
              <li><a href="Contactuspage.php">CONTACT US</a></li>
              <li><a href="about.php">ABOUT</a></li>
              <li><a href="logout.php">Logout</a></li>
            </ul>

</div> 
<div class = "container">
<?php
// (A) PROCESS ORDER FORM
if (isset($_POST["fname"])) {
  require "process2.php"; 
  echo $result == "" 
    ? "<div class='notify'>Thank You! We have received your messaged!</div>" 
    : "<div class='notify'>$result</div>" ;
}
?>
<form method="post" target="_self">
<h2 class="title-2">For more inquiries, <br> <span>Please</span> Cont</span>act us. </br> </h2>
  <label>Firstname</label>
  <input type="text" name="fname"placeholder= "Enter your firstname " required value = "" >
 
  <label>Surname</label>
  <input type="surname" name="surname" placeholder= "Enter your lastname" required value = "">

  <label>Email Address</label>
  <input type="email" name="email" placeholder= "Enter your email address" required value = "" >

  <label>Phone #</label>
  <input type="phone" name="phone" required value = "" placeholder = "09XX-XXX-XXXX">

  <label>Message</label>
  <input type="message" name="message"  placeholder = "Type your message here" >



  <input type="submit" value="submit" >
</form>
</div>
  </body>

  <footer>
    <div class="footer-grid">
        <ul class="contact-info">
            <li><h4>Contact Information</h4></li>
            <li><strong>Phone:</strong> (+63) 965-390-8872</li>
            <li><strong>Email:</strong> coffeeshopweb@gmail.com</li>
            <li><strong>Address:</strong> 464 Santo Rosario St, Angeles, Pampanga</li>
        </ul>
        <ul class="social-media">
        <li><h4> <a href="https://www.canva.com/design/DAFhwtCI6UA/HNiZMGQEZMoy9Ys2_MzBcA/edit?utm_content=DAFhwtCI6UA&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton" >Social Media</h4> </a></li>
            <li><a href="https://www.canva.com/design/DAFhwtCI6UA/HNiZMGQEZMoy9Ys2_MzBcA/edit?utm_content=DAFhwtCI6UA&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
        </ul>
        <ul class="legal">
            <li><a href="https://docs.google.com/document/d/1xYnU9C4r-P7f4fRulPx9LGGQ6UCwoIPs/" target="_blank">Privacy Policy and Terms of Service</a></li>
        </ul>
    </div>
    </footer>


</html>