<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv= "X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Kopi | Shop</title>

</head>

	  

<body>

<div class = "container">
        <div class = "nav-bar">
        <h1 class="title" >Cof<span>fee</span></h1> </a>
            <p> Kopi | Shop </p>
            <ul class="menu">
            <li><a href="login.php">Login</a></li>
            
            </ul>
        </div>

<?php
if (isset($_POST["user_name"])) {
  if (strtolower($_POST["user_name"]) === "admin") {
    echo $result = "<div class='notify'>You cannot use admin, please choose another one.</div>";
  } else {
    require "process3.php"; 
    echo $result = $result == "" 
      ? "<div class='notify'>You are already registered! Please Log in</div>" 
      : "<div class='notify'>$result</div>";
  }
}
?>




<form method="post" target="_self">
<h2 class="title-2">Create an <span>Account.</span> </h2>
  <label>Create a username</label>
  <input type="text" name="user_name"placeholder= "Enter your username">
 
  <label>Create a password</label>
  <input type="password" name="password" placeholder= "Enter your password">

  <?php

?>

  <input type="submit" value="Sign up" >
</form>

</div>
  </body>

  <footer>
    <div class="footer-grid">
        <ul class="contact-info">
            <li><h4>Contact Information</h4></li>
            <li><strong>Phone:</strong> (+63) 965-390-8872</li>
            <li><strong>Email:</strong> coffeeshopweb@gmail.com</li>
            <li><strong>Address:</strong> 464 Santo Rosario St, Angeles, Pampanga</li>
        </ul>
        <ul class="social-media">
        <li><h4> <a href="https://www.canva.com/design/DAFhwtCI6UA/HNiZMGQEZMoy9Ys2_MzBcA/edit?utm_content=DAFhwtCI6UA&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton" >Social Media</h4> </a></li>
            <li><a href="https://www.canva.com/design/DAFhwtCI6UA/HNiZMGQEZMoy9Ys2_MzBcA/edit?utm_content=DAFhwtCI6UA&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
        </ul>
        <ul class="legal">
            <li><a href="https://docs.google.com/document/d/1xYnU9C4r-P7f4fRulPx9LGGQ6UCwoIPs/" target="_blank">Privacy Policy and Terms of Service</a></li>
        </ul>
    </div>
    </footer>


</html>