
<!DOCTYPE html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv= "X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Kopi | Shop</title>

</head>

<body>
    
<div class = "container">
        <div class = "nav-bar">
        <a> <h1 class="title" >Cof<span>fee</span></h1> </a>
            <p> Kopi | Shop </p>
            <ul class="menu">
            <li><a href="Signup.php">Sign up</a></li>
            
            </ul>

            
        </div>


<form action="login.php" method="post">
<h2 class="title-2"> <span>Login</span> </h2>

<label>Username</label>
<input type="text" name="uname" placeholder="Username"><br>

<label>Password</label>
<input type="password" name="password" placeholder="Password"><br> 


<input type="submit" value="Login">

</form>


</div>
</body>
<footer>
    <div class="footer-grid">
        <ul class="contact-info">
            <li><h4>Contact Information</h4></li>
            <li><strong>Phone:</strong> (+63) 965-390-8872</li>
            <li><strong>Email:</strong> coffeeshopweb@gmail.com</li>
            <li><strong>Address:</strong> 464 Santo Rosario St, Angeles, Pampanga</li>
        </ul>
        <ul class="social-media">
        <li><h4> <a href="https://www.canva.com/design/DAFhwtCI6UA/HNiZMGQEZMoy9Ys2_MzBcA/edit?utm_content=DAFhwtCI6UA&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton" >Social Media</h4> </a></li>
            <li><a href="https://www.canva.com/design/DAFhwtCI6UA/HNiZMGQEZMoy9Ys2_MzBcA/edit?utm_content=DAFhwtCI6UA&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
        </ul>
        <ul class="legal">
            <li><a href="https://docs.google.com/document/d/1xYnU9C4r-P7f4fRulPx9LGGQ6UCwoIPs/" target="_blank">Privacy Policy and Terms of Service</a></li>
        </ul>
    </div>
    </footer>
    

</html>

