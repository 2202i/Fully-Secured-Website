-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 04, 2023 at 11:18 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `dop` datetime NOT NULL DEFAULT current_timestamp(),
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `Coffee` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `dop`, `name`, `email`, `Coffee`, `qty`) VALUES
(28, '2023-04-23 19:30:35', 'Juan Dela Cruz', 'Juan_DelaCruz@a.com', 'Black Coffee', 1),
(29, '2023-04-23 20:58:58', 'Juan Dela Cruz', 'Juan_DelaCruz@a.com', 'Black Coffee', 2),
(30, '2023-04-23 22:20:38', 'Juan Dela Cruz', 'Juan_DelaCruz@a.com', 'Black Coffee', 1),
(31, '2023-04-23 23:00:59', 'Juan Dela Cruz', 'Juan_DelaCruz@a.com', 'Black Coffee', 1),
(32, '2023-04-27 01:33:54', 'Juan Dela Cruz', 'Juan_DelaCruz@a.com', 'Black Coffee', 1),
(33, '2023-04-27 15:53:28', '', '', '', 0),
(34, '2023-04-27 15:53:53', '', '', '', 0),
(35, '2023-04-27 15:53:58', '', '', '', 0),
(36, '2023-05-01 16:34:13', 'r', 'reinel.garcia09.rg@gmail.com', 'black coffee', 1),
(37, '2023-05-01 16:35:16', 'r', 'reinel.garcia09.rg@gmail.com', 'black coffee', 1),
(38, '2023-05-01 16:40:02', 'Reinel Garcia', 'reinel.garcia09.rg@gmail.com', 'black coffee', 1),
(39, '2023-05-01 16:40:50', 'Reinel Garcia', 'reinel.garcia09.rg@gmail.com', 'black coffee', 1),
(40, '2023-05-01 16:41:05', 'Reinel Garcia', 'reinel.garcia09.rg@gmail.com', 'black coffee', 1),
(41, '2023-05-01 16:41:15', 'Reinel Garcia', 'reinel.garcia09.rg@gmail.com', 'black coffee', 1),
(42, '2023-05-01 16:41:27', 'Reinel Garcia', 'reinel.garcia09.rg@gmail.com', 'black coffee', 1),
(43, '2023-05-01 16:41:38', 'Reinel Garcia', 'reinel.garcia09.rg@gmail.com', 'black coffee', 1),
(44, '2023-05-01 16:41:56', 'Reinel Garcia', 'reinel.garcia09.rg@gmail.com', 'black coffee', 1),
(45, '2023-05-01 16:42:09', 'Reinel Garcia', 'reinel.garcia09.rg@gmail.com', 'tunapuff', 1),
(46, '2023-05-01 16:42:41', 'Reinel Garcia', 'reinel.garcia09.rg@gmail.com', 'tunapuff', 1),
(47, '2023-05-01 16:42:46', 'Reinel Garcia', 'reinel.garcia09.rg@gmail.com', 'tunapuff', 2),
(48, '2023-05-01 19:06:26', 'Jonel Mallari', 'jonel@gmail.com', 'Tuna puff', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
