<?php

// (A) PROCESS RESULT
$result = "";

// (B) CONNECT TO DATABASE - CHANGE SETTINGS TO YOUR OWN!
$dbhost = "localhost";
$dbname = "test";
$dbchar = "utf8mb4";
$dbuser = "root";
$dbpass = "";
$pdo = new PDO(
  "mysql:host=$dbhost;dbname=$dbname;charset=$dbchar",
  $dbuser, $dbpass, [
  PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
  PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
]);

if ($result=="") { try {
  $file = isset($_POST["file"]) ? $_POST["file"] : null; // Check if 'file' field is set
  $stmt = $pdo->prepare("INSERT INTO `orders` (`name`,`email`,`qty`,`coffee`,`file`) VALUES (?,?,?,?,?)");
  $stmt->execute([$_POST["name"], $_POST["email"], $_POST["qty"],$_POST["coffee"],["file"]]);
} catch (Exception $ex) { $result = $ex->getMessage(); }}



