<?php
session_start();
?>

<!DOCTYPE html>


<head>
    <meta charset="UTF-8">
    <meta http-equiv= "X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Kopi | Shop</title>

</head>



<body>
    <div class = "container">
        <div class = "nav-bar">
            <h1 class="title" >Cof<span>fee</span></h1> </a>
            <p> Coffee Shop </p>
            <ul class="menu">
            <li><a href="homepageadmin.php">HOME</a></li>
            <li><a href="admin.php">ADMIN</a></li>
            <li><a href="Contactuspageadmin.php">CONTACT US</a></li>
            <li><a href="aboutadmin.php">ABOUT</a></li>
            <li><a href="logout.php">Logout</a></li>
            
            </ul>
        </div>
  

    <div class="home">
        <h1 class="title-1">We like to keep it <span>Simple.</span> Everyone</span><br> in the <span>Coffee</span> Chain must be able to live <span>healthy</span>. </h1>
        <p>We provide a variety of unique and Best Coffee!</p>
        <h1>Hello! <?php echo $_SESSION['user_name']; ?></h1>
        <a href="products.php" ><button type="button"> Shop Now!  </button>
   </div>
</div>


<footer>

<div class="footer-grid">
    <ul class="contact-info">
        <li><h4>Contact Information</h4></li>
        <li><strong>Phone:</strong> (+63) 965-390-8872</li>
        <li><strong>Email:</strong> coffeeshopweb@gmail.com</li>
        <li><strong>Address:</strong> 464 Santo Rosario St, Angeles, Pampanga</li>
    </ul>
    <ul class="social-media">
    <li><h4> <a href="https://www.canva.com/design/DAFhwtCI6UA/HNiZMGQEZMoy9Ys2_MzBcA/edit?utm_content=DAFhwtCI6UA&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton" >Meet our Team</h4> </a></li>
        <li><a href="https://www.canva.com/design/DAFhwtCI6UA/HNiZMGQEZMoy9Ys2_MzBcA/edit?utm_content=DAFhwtCI6UA&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
    </ul>
    <ul class="legal"> 
        <li><a href="https://docs.google.com/document/d/1xYnU9C4r-P7f4fRulPx9LGGQ6UCwoIPs/" target="_blank">Privacy Policy and Terms of Service</a></li>
    </ul>
</div>
</footer>

</body>
</html>
